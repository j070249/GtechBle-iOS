//
//  whizconnect_sdk.h
//  whizconnect-sdk
//
//  Created by Jimmy Tai on 2020/1/3.
//  Copyright © 2020 SEDA G-Tech. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for whizconnect_sdk.
FOUNDATION_EXPORT double whizconnect_sdkVersionNumber;

//! Project version string for whizconnect_sdk.
FOUNDATION_EXPORT const unsigned char whizconnect_sdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <whizconnect_sdk/PublicHeader.h>


